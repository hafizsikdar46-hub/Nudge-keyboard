package com.nudge.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("nudge", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad * 2, pad, pad)

        fun addText(text: String, size: Float) {
            val tv = TextView(this)
            tv.text = text
            tv.textSize = size
            tv.setPadding(0, pad / 2, 0, pad / 4)
            col.addView(tv)
        }

        fun addButton(text: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = text
            b.isAllCaps = false
            b.setOnClickListener { onClick() }
            col.addView(b)
        }

        fun saveTheme(name: String) {
            prefs.edit().putString("theme", name).apply()
            Toast.makeText(this, "Theme saved: $name", Toast.LENGTH_SHORT).show()
        }

        addText("Nudge Keyboard", 26f)
        addText("Step 1: enable it. Step 2: choose it. Step 3: test below.", 15f)
        addButton("1. Enable Nudge Keyboard") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        addButton("2. Choose Nudge Keyboard") {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        addText("Theme", 18f)
        addButton("Nudge Purple") { saveTheme("purple") }
        addButton("White") { saveTheme("white") }
        addButton("Black") { saveTheme("black") }
        addText("Test", 18f)
        val et = EditText(this)
        et.hint = "Type here to test"
        col.addView(et)

        val scroll = ScrollView(this)
        scroll.addView(col)
        setContentView(scroll)
    }
}
