package com.nudge.keyboard

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

data class NudgeTheme(
    val bg: Int,
    val key: Int,
    val special: Int,
    val text: Int,
    val hint: Int,
    val accent: Int,
    val accentText: Int
)

fun themeFor(name: String?): NudgeTheme = when (name) {
    "white" -> NudgeTheme(
        Color.parseColor("#D3D6DD"), Color.parseColor("#FFFFFF"), Color.parseColor("#ADB3BF"),
        Color.parseColor("#111111"), Color.parseColor("#555B66"),
        Color.parseColor("#7B5CD6"), Color.parseColor("#FFFFFF")
    )
    "black" -> NudgeTheme(
        Color.parseColor("#000000"), Color.parseColor("#3A3A3C"), Color.parseColor("#1C1C1E"),
        Color.parseColor("#FFFFFF"), Color.parseColor("#8E8E93"),
        Color.parseColor("#7B5CD6"), Color.parseColor("#FFFFFF")
    )
    else -> NudgeTheme(
        Color.parseColor("#4A2F8F"), Color.parseColor("#7B5CD6"), Color.parseColor("#5E43B0"),
        Color.parseColor("#FFFFFF"), Color.parseColor("#C9BBF2"),
        Color.parseColor("#FFC857"), Color.parseColor("#2B1B54")
    )
}

class NudgeIME : InputMethodService() {

    private lateinit var root: LinearLayout
    private var shifted = false
    private var caps = false
    private var symbols = false
    private val handler = Handler(Looper.getMainLooper())
    private var repeater: Runnable? = null

    private val letterRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val symbolRows = listOf("1234567890", "-/:;()\$&@\"", ".,?!'+=")

    override fun onCreateInputView(): View {
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        symbols = false
        caps = false
        shifted = false
        if (info != null && info.inputType != InputType.TYPE_NULL) {
            val mode = currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0
            shifted = mode != 0
        }
        if (::root.isInitialized) render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        stopRepeat()
        super.onFinishInputView(finishingInput)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun rerender() {
        handler.post { render() }
    }

    private fun render() {
        val prefs = getSharedPreferences("nudge", MODE_PRIVATE)
        val t = themeFor(prefs.getString("theme", "purple"))
        root.removeAllViews()
        root.setBackgroundColor(t.bg)
        root.setPadding(dp(4), dp(2), dp(4), dp(6))

        // Suggestion bar (placeholder for now; autocorrect comes in the next step)
        val bar = TextView(this)
        bar.text = "Nudge"
        bar.setTextColor(t.hint)
        bar.gravity = Gravity.CENTER
        bar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)))

        if (!symbols) {
            addRow(buildList<View> {
                letterRows[0].forEach { add(charKey(it.toString(), t)) }
            })
            addRow(buildList<View> {
                add(spacer(0.5f))
                letterRows[1].forEach { add(charKey(it.toString(), t)) }
                add(spacer(0.5f))
            })
            addRow(buildList<View> {
                val label = if (caps) "\u21EA" else "\u21E7"
                val bg = if (shifted) t.accent else t.special
                val fg = if (shifted) t.accentText else t.text
                add(makeKey(label, 1.5f, bg, fg, 20f, false) {
                    if (caps) {
                        caps = false
                        shifted = false
                    } else if (shifted) {
                        caps = true
                    } else {
                        shifted = true
                    }
                    rerender()
                })
                letterRows[2].forEach { add(charKey(it.toString(), t)) }
                add(deleteKey(t))
            })
        } else {
            addRow(buildList<View> {
                symbolRows[0].forEach { add(charKey(it.toString(), t)) }
            })
            addRow(buildList<View> {
                symbolRows[1].forEach { add(charKey(it.toString(), t)) }
            })
            addRow(buildList<View> {
                add(spacer(1.5f))
                symbolRows[2].forEach { add(charKey(it.toString(), t)) }
                add(deleteKey(t))
            })
        }

        addRow(buildList<View> {
            add(makeKey(if (symbols) "ABC" else "?123", 1.5f, t.special, t.text, 15f, false) {
                symbols = !symbols
                rerender()
            })
            add(charKey(",", t))
            add(makeKey("space", 5f, t.key, t.hint, 14f, false) { typeText(" ") })
            add(charKey(".", t))
            add(makeKey("\u23CE", 1.5f, t.accent, t.accentText, 20f, false) { enter() })
        })
    }

    private fun addRow(views: List<View>) {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        for (v in views) l.addView(v)
        root.addView(
            l,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
    }

    private fun spacer(weight: Float): View {
        val v = View(this)
        val lp = LinearLayout.LayoutParams(0, dp(44), weight)
        lp.setMargins(dp(3), dp(5), dp(3), dp(5))
        v.layoutParams = lp
        return v
    }

    private fun charKey(c: String, t: NudgeTheme): View {
        val shown = if (!symbols && shifted) c.uppercase() else c
        return makeKey(shown, 1f, t.key, t.text, 20f, false) { typeText(shown) }
    }

    private fun deleteKey(t: NudgeTheme): View {
        return makeKey("\u232B", 1.5f, t.special, t.text, 20f, true) { backspace() }
    }

    private fun makeKey(
        label: String,
        weight: Float,
        bg: Int,
        fg: Int,
        sp: Float,
        repeat: Boolean,
        action: () -> Unit
    ): TextView {
        val k = TextView(this)
        k.text = label
        k.gravity = Gravity.CENTER
        k.setTextColor(fg)
        k.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        k.maxLines = 1

        val shape = GradientDrawable()
        shape.shape = GradientDrawable.RECTANGLE
        shape.cornerRadius = dp(7).toFloat()
        shape.setColor(bg)
        k.background = shape
        k.elevation = dp(1).toFloat()

        val lp = LinearLayout.LayoutParams(0, dp(44), weight)
        lp.setMargins(dp(3), dp(5), dp(3), dp(5))
        k.layoutParams = lp

        k.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.6f
                    action()
                    if (repeat) startRepeat(action)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = 1f
                    stopRepeat()
                }
            }
            true
        }
        return k
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 50)
            }
        }
        repeater = r
        handler.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        repeater?.let { handler.removeCallbacks(it) }
        repeater = null
    }

    private fun typeText(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (shifted && !caps) {
            shifted = false
            rerender()
        }
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (sel != null && sel.isNotEmpty()) {
            ic.commitText("", 1)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
    }

    private fun enter() {
        val ei = currentInputEditorInfo
        val ic = currentInputConnection ?: return
        val opts = ei?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnter = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (noEnter || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            ic.performEditorAction(action)
        }
    }
}
